package com.bytedance.caijing.tt_pay.model;

public class TestTradeQueryResponse {
}
