package com.bytedance.caijing.tt_pay.net;

public class TestTPResponse {
}
