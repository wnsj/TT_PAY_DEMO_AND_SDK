# 财经支付
简要介绍

## 目录
- [安装](#安装)
- [依赖版本](#依赖版本)
- [快速接入](#快速接入)
- [API示例](#API示例)

## 安装
安装财经支付SDK前，请确保安装Java并正确设置环境变量。
下载SDK：
#
①手动安装
```
在 Github或小程序开发者文档——支付页面内下载 SDK,将 libs/ 下面的 jar 包导入工程。
```
②maven 安装

设置maven私有仓库地址
```
<repositories>
    <repository>
        <id>bytedance-snapshots</id>
        <url>http://maven.byted.org/repository/snapshots</url>
    </repository>
    <repository>
        <id>bytedance-releases</id>
        <url>http://maven.byted.org/repository/releases</url>
    </repository>
</repositories>
```

在pom文件中添加依赖(依赖最新版本1.0.4)

```
<dependency>
     <groupId>com.bytedance.caijing</groupId>
    <artifactId>tt-pay</artifactId>
    <version>1.0.4</version>
</dependency>
```


## 版本

## 快速接入

本部分以预下单接口为例，演示如何快速接入财经支付SDK。其他接口的接入方法与预下单接口类似，主要差别在于商户传入参数不同。小程序支付请参考SDK内注释，其他支付方式请参考https://pay-doc.bytedance.net/。

#### 步骤一：设置

TTPayLog.LogLevel可设置是否Log模式，一共有debug，info，warn，error四种模式可选
```
TTPayLog.logLevel = TTPayLog.LogLevel.debug
```
#### 步骤二：创建预下单请求

使用SDK提供的New函数创建请求时，会自动设置部分参数为默认值，这些参数包括：
 - Version = "2.0"
 - SignType = "MD5"
 - CashdeskTradeType = "H5" (只在预下单时需要，默认为H5)
 - Config.TPDomain = "https://tp-pay.snssdk.com"
 
要自定义参数，请仔细查阅接入手册https://pay-doc.bytedance.net/,小程序开发者请参考SDK内注释
```
        TTPayService.appId = "你的APPID";
        TTPayService.appSecret = "你的APP密钥";
        TTPayService.merchantId = "商户号";
        TTPayService.tpDomain = "https://tp-pay.snssdk.com";
        TradeCreateRequest request = TradeCreateRequest.builder()
                .CashdeskTradeType("MD5")
                .version("2.0")
                .outOrderNo("" + System.currentTimeMillis())
                .uid("123")
                .totalAmount(1L)
                .currency("CNY")
                .subject("测试订单")
                .body("测试订单内容")
                .tradeTime("" + System.currentTimeMillis() / 1000)
                .validTime("3600")
                .notifyUrl("https://tp-pay.snssdk.com/callback_success?app_id=8000000xxxxx\"")
                .riskInfo("{\"ip\":\"127.0.0.1\", \"device_id\":\"122333\"}")
                .build();
```

#### 步骤三：调用接口，处理业务逻辑

```
// 调用下单接口，获取下单凭据
TradeCreateResponse response = TTPayService.TradeCreate(request);
String appletParams = response.getAppletParams();
// 你的业务逻辑
DoSomething()
```

## API示例

完整的各API使用Demo可以在https://pay-doc.bytedance.net/apis找到。
完整的开发文档可在https://pay-doc.bytedance.net/找到。
注意：为使接口正常工作，请务必按照开发文档要求正确传入所有参数，漏传、多传以及不正确的参数格式将使接口失效！

### 预下单接口 
```
// 预下单接口
TradeCreateResponse response = TTPayService.TradeCreate(request);
```
### 订单查询接口
```
// 订单查询接口
TradeQueryResponse response = TTPayService.TradeQuery(request);
```
### 退款申请接口

```
// 退款申请接口
RefundCreateResponse response = TTPayService.RefundCreate(request);
```

### 退款查询接口
```
// 退款查询接口
RefundQueryResponse response = TTPayService.RefundQuery(request);
```

### 支付回调接口
```
// 支付回调接口
TradeNotifyResponse response = TTPayService.TradeNotify(request);
```

### 退款回调接口
```
// 退款回调接口
RefundNotifyResponse response = TTPayService.RefundNotify(request);
```
