package com.bytedance.caijing.cashdesk_applet;

import com.bytedance.caijing.tt_pay.TTPayLog;
import com.bytedance.caijing.tt_pay.TTPayService;
import com.bytedance.caijing.tt_pay.model.TradeCreateRequest;
import com.bytedance.caijing.tt_pay.model.TradeCreateResponse;

public class TradeCreateDemo {
    public static void main(String[] args) {
        TTPayLog.logLevel = TTPayLog.LogLevel.debug;     //log级别可配置为 debug，info，warn，error
        TTPayService.appId = "--------------";//支付方分配给业务方的ID，用于获取 签名/验签 的密钥信息
        TTPayService.appSecret = "--------------";//支付方密钥
        TTPayService.merchantId = "--------------";//支付方分配给业务方的商户编号
        TTPayService.tpDomain = "https://tp-pay-test.snssdk.com"; // 测试请用https://tp-pay-test.snssdk.com, 线上请用https://tp-pay.snssdk.com
        TradeCreateRequest request = TradeCreateRequest.builder()

                // 下面两个版本号，AppletVersion指的是小程序收银台版本，Version指的是财经后端下单接口版本
                // 小程序收银台版本有1.0和2.0，头条APP只在7.2.7之后支持收银台2.0版本，7.2.7之前的版本请使用1.0
                // 该参数可设置为"1.0"(返回拉起1.0收银台参数)，"2.0"(返回拉起2.0收银台参数),"2.0+"(返回一个json，包含1.0和2.0参数)，"3.0"(返回拉起3.0收银台参数)

                .appletVersion("3.0")                                          // 小程序收银台版本，可选1.0，2.0及2.0+
                .version("2.0")                                                 // 后端下单接口默认为2.0， 可更改为1.0
                .outOrderNo("" + System.currentTimeMillis())                    // 此处是随机生成的，使用时请填写您的商户订单号
                .uid("123")                                                     // 填写用户在头条的uid
                .totalAmount(1L)                                                // 填写订单金额
                .currency("CNY")                                                // 填写币种，一般均为CNY
                .subject("测试订单")                                             // 填写您的订单名称
                .body("测试订单内容")                                             // 填写您的订单内容
                .tradeTime("" + System.currentTimeMillis() / 1000)              // 交易时间，此处自动生成，您也可以根据需求赋值，但必须为Unix时间戳
                .validTime("3600")                                              // 填写您的订单有效时间（单位：秒）
                .notifyUrl("http://www.baidu.com")                              // 填写您的异步通知地址
                .riskInfo("{\"ip\":\"127.0.0.1\", \"device_id\":\"122333\"}")   // 严格json字符串格式
                .productCode("pay")                                             // 固定值，不要改动
                .tradeType("H5")                                                // 固定值，不要改动

                // 1.0版本特有参数，当AppletVersion填"1.0"和"2.0+"时需要填写
                .params("...")                                    // 传递给支付方的支付信息，不同的支付方参数格式不一样
                .payType("ALIPAY_APP")                                          // 1.0版本的PayType，目前只支持支付宝，请填写ALIPAY_APP
                .payChannel("ALIPAY_NO_SIGN")                                   // 目前只支持支付宝，请填写ALIPAY_NO_SIGN

                // 2.0版本特有参数，当AppletVersion填"2.0", "2.0+" 和 "3.0"时需要填写
                .paymentType("direct")                                          // 2.0版本的PaymentType，固定值direct，不要改动
                .wxUrl("")                                                      // 调用微信H5支付统一下单接口返回的mweb_url字段值。service=1时(外部开发者)必传，否则无法使用微信支付; 内部用户该参数不用传
                .wxType("")                                                     // service=1时(外部开发者)，且wx_url有值时，传固定值：MWEB; 内部用户该参数不用传
                .alipayUrl("")                                                  // 调用支付宝App支付的签名订单信息，详见支付宝App支付请求参数说明。service=1时(外部开发者)必传，否则无法使用支付宝支付; 内部用户该参数不用
                .build();
        try {
            TradeCreateResponse response = TTPayService.TradeCreate(request);
            String appletParams = response.getAppletParams();
            System.out.println("Get Cashdesk Parameters: " + appletParams);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
