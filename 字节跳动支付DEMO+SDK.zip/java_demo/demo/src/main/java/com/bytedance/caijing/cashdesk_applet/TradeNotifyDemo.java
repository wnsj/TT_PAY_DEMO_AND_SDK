package com.bytedance.caijing.cashdesk_applet;


import com.bytedance.caijing.tt_pay.TTPayService;
import com.bytedance.caijing.tt_pay.model.TradeNotifyRequest;
import com.bytedance.caijing.tt_pay.model.TradeNotifyResponse;

public class TradeNotifyDemo {
    public static void main(String[] args){
        //支付回调
        //接口说明：支付结果回调业务
        String notify_body = "";//请输入回调主题
        TradeNotifyRequest request = TradeNotifyRequest.builder()
                .param(notify_body)
                .build();
        try {
            TradeNotifyResponse response = TTPayService.TradeNotify(request);
            System.out.println("TradeNotifyDemo req: " + request.toString());
            System.out.println("TradeNotifyDemo resp: " + response.toString());
            System.out.println("TradeNotifyDemo resp: " + response.getExtension());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
