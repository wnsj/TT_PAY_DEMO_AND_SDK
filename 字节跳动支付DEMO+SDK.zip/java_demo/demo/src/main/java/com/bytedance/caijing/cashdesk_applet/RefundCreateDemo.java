package com.bytedance.caijing.cashdesk_applet;


import com.bytedance.caijing.tt_pay.TTPayLog;
import com.bytedance.caijing.tt_pay.TTPayService;
import com.bytedance.caijing.tt_pay.model.RefundCreateRequest;
import com.bytedance.caijing.tt_pay.model.RefundCreateResponse;


public class RefundCreateDemo {
    public static void main(String[] args) {
        TTPayLog.logLevel = TTPayLog.LogLevel.debug;     //log级别可配置为 debug，info，warn，error
        TTPayService.appId = "-------------------------";//支付方分配给业务方的ID，用于获取 签名/验签 的密钥信息
        TTPayService.appSecret = "---------------------";//支付方密钥
        TTPayService.merchantId = "--------------------";//支付方分配给业务方的商户编号
        TTPayService.tpDomain = "https://tp-pay-test.snssdk.com"; // 测试请用https://tp-pay-test.snssdk.com, 线上请用https://tp-pay.snssdk.com
        RefundCreateRequest request = RefundCreateRequest.builder()
                .uid("20190402165728")                                          // 填写用户在头条的id
                .tradeNo("SP2019052721254910332124300514")                      // 填写商户订单号
                .outRefundNo(""+System.currentTimeMillis())                     // 此处是随机生成的，使用时请填写您的商户退款单号
                .refundAmount(1L)                                               // 填写您的退款金额
                .notifyUrl("https://google.com") // 填写您的异步通知地址
                .riskInfo("{\"ip\":\"127.0.0.1\", \"device_id\":\"122333\"}")   // 严格json字符串格式
                .build();
        try {
            RefundCreateResponse response = TTPayService.RefundCreate(request);
            System.out.println("RefundQueryDemo req: " + request.toString());
            System.out.println("RefundQueryDemo resp: " + response.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
