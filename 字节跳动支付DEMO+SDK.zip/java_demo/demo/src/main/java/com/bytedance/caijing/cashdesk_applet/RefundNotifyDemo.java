package com.bytedance.caijing.cashdesk_applet;


import com.bytedance.caijing.tt_pay.TTPayService;
import com.bytedance.caijing.tt_pay.model.RefundNotifyRequest;
import com.bytedance.caijing.tt_pay.model.RefundNotifyResponse;

public class RefundNotifyDemo {
    public static void main(String[] args){
        //退款回调
        //接口说明：退款结果回调业务
        String notify_body = "";//请输入回调主题
		RefundNotifyRequest request = RefundNotifyRequest.builder()
            .param(notify_body)
            .build();
        try {
            RefundNotifyResponse response = TTPayService.RefundNotify(request);
            System.out.println("RefundQueryDemo req: " + request.toString());
            System.out.println("RefundQueryDemo resp: " + response.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
