package com.bytedance.caijing.cashdesk_applet;

import com.bytedance.caijing.tt_pay.TTPayLog;
import com.bytedance.caijing.tt_pay.TTPayService;
import com.bytedance.caijing.tt_pay.model.RefundQueryRequest;
import com.bytedance.caijing.tt_pay.model.RefundQueryResponse;

public class RefundQueryDemo {
    public static void main(String[] args) {
        TTPayLog.logLevel = TTPayLog.LogLevel.debug;     //log级别可配置为 debug，info，warn，error
        TTPayService.appId = "-------------------------";//支付方分配给业务方的ID，用于获取 签名/验签 的密钥信息
        TTPayService.appSecret = "---------------------";//支付方密钥
        TTPayService.merchantId = "--------------------";//支付方分配给业务方的商户编号
        TTPayService.tpDomain = "https://tp-pay-test.snssdk.com"; // 测试请用https://tp-pay-test.snssdk.com, 线上请用https://tp-pay.snssdk.com
        RefundQueryRequest request = RefundQueryRequest.builder()
                .uid("123")
                .outRefundNo("1564039958701")
                .build();
        try {
            RefundQueryResponse response = TTPayService.RefundQuery(request);
            System.out.println("RefundQueryDemo req: " + request.toString());
            System.out.println("RefundQueryDemo resp: " + response.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
