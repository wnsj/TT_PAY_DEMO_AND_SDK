package com.bytedance.caijing.cashdesk_applet;

import com.bytedance.caijing.tt_pay.TTPayLog;
import com.bytedance.caijing.tt_pay.TTPayService;
import com.bytedance.caijing.tt_pay.model.TradeQueryRequest;
import com.bytedance.caijing.tt_pay.model.TradeQueryResponse;

public class TradeQueryDemo {
    public static void main(String[] args) {
        TTPayLog.logLevel = TTPayLog.LogLevel.debug;     //log级别可配置为 debug，info，warn，error
        TTPayService.appId = "---------------------------";   //支付方分配给业务方的ID，用于获取 签名/验签 的密钥信息
        TTPayService.appSecret = "-----------------------";   //支付方密钥
        TTPayService.merchantId = "----------------------";  //支付方分配给业务方的商户编号
        TTPayService.tpDomain = "https://tp-pay-test.snssdk.com"; // 测试请用https://tp-pay-test.snssdk.com, 线上请用https://tp-pay.snssdk.comlea
        TradeQueryRequest request = TradeQueryRequest.builder()
                .outOrderNo("1564038590")                   // 此处是随机生成的，使用时请填写您的商户订单号
                .uid("123")                                 // 填写用户在头条的id
                .build();
        try {
            TradeQueryResponse response = TTPayService.TradeQuery(request);
            System.out.println("TradeQueryDemo req: " + request.toString());
            System.out.println("TradeQueryDemo resp: " + response.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}

